import type { MarketRegime } from "@/lib/market";

export type EtfCategory = "CORE" | "GROWTH" | "TECH" | "DIVIDEND" | "SECTOR" | "DEFENSIVE";
export type EtfSignal = "ACCUMULATE" | "HOLD" | "WATCH" | "REDUCE" | "EXIT";
export type EtfShortTermSignal = "SHORT_BUY" | "READY" | "WAIT" | "OVERHEATED" | "AVOID";
export type EtfComplianceStatus = "ELIGIBLE" | "PRE_APPROVAL_REQUIRED" | "NOT_ELIGIBLE" | "UNKNOWN";
export type EtfDiversificationType = "BROAD" | "FOCUSED" | "NARROW" | "UNKNOWN";

export type EtfComplianceProfile = {
  holdingsCount?: number | null;
  maxHoldingWeight?: number | null;
  derivativeBased?: boolean | null;
  derivativeExposureType?: string | null;
  diversificationType?: EtfDiversificationType;
  diversificationScore?: number | null;
  sourceNote?: string | null;
};

export type EtfComplianceResult = {
  status: EtfComplianceStatus;
  reasons: string[];
  holdingsCount: number | null;
  maxHoldingWeight: number | null;
  derivativeBased: boolean | null;
};

export type EtfReboundStatus = "FALLING" | "OVERSOLD" | "PREPARING" | "CONFIRMED" | "EXTENDED";

export type EtfReboundResult = {
  score: number;
  status: EtfReboundStatus;
  oversoldScore: number;
  reversalScore: number;
  trendRepairScore: number;
  regimeScore: number;
  reasons: string[];
};

export type EtfMasterItem = {
  symbol: string;
  yahooSymbol: string;
  name: string;
  shortName: string;
  issuer: string;
  category: EtfCategory;
  strategy: string;
  benchmark: string;
  enabled: boolean;
  priority: number;
  tags: string[];
  compliance?: EtfComplianceProfile;
};

export type EtfPriceMetrics = {
  asOf: string;
  price: number;
  previousClose: number | null;
  changePercent1d: number | null;
  return7d: number | null;
  return20d: number | null;
  return60d: number | null;
  return120d: number | null;
  movingAverage20: number | null;
  movingAverage50: number | null;
  movingAverage200: number | null;
  distanceFromMa20: number | null;
  distanceFromMa50: number | null;
  distanceFromMa200: number | null;
  volatility20d: number | null;
  drawdownFromHigh: number | null;
  averageVolume20d: number | null;
  sampleSize: number;
};

export type EtfScoreBreakdown = {
  trend: number;
  momentum: number;
  risk: number;
  liquidity: number;
  regimeFit: number;
};

export type EtfShortTermBreakdown = {
  momentum7d: number;
  momentum20d: number;
  trend: number;
  acceleration: number;
  risk: number;
  regimeFit: number;
  liquidity: number;
};

export type EtfAnalysis = {
  master: EtfMasterItem;
  metrics: EtfPriceMetrics;
  score: number;
  legacyScore: number;
  overextensionPenalty: number;
  exitScore: number;
  signal: EtfSignal;
  breakdown: EtfScoreBreakdown;
  marketRegime: MarketRegime;
  reasons: string[];
  warnings: string[];
  scoreVersion: string;
  legacyScoreVersion: string;
  shortTermScore: number;
  legacyShortTermScore: number;
  legacyShortTermSignal: EtfShortTermSignal;
  legacyShortTermScoreVersion: string;
  shortTermSignal: EtfShortTermSignal;
  shortTermBreakdown: EtfShortTermBreakdown;
  shortTermOverheatPenalty: number;
  shortTermReasons: string[];
  shortTermScoreVersion: string;
  compliance: EtfComplianceResult;
  diversificationType: EtfDiversificationType;
  diversificationScore: number | null;
  rebound: EtfReboundResult;
};

